"""检查配置对象。"""

from __future__ import annotations

from dataclasses import dataclass

#: 默认缺失值标记（比较时忽略大小写）。空字符串表示“去掉空白后为空的单元格”。
DEFAULT_NA_VALUES: frozenset[str] = frozenset({"", "na", "n/a", "null", "none", "nan"})


@dataclass(frozen=True)
class CheckConfig:
    """一次检查所使用的全部可调参数。

    Attributes:
        na_values: 额外被视为缺失值的标记集合，比较时忽略大小写。
            空单元格始终被计为缺失，与该集合无关。
        delimiter: 字段分隔符；``None`` 表示自动嗅探。
        encoding: 文件编码；``None`` 表示自动嗅探。
        has_header: 首行是否为表头。
        trim_whitespace: 判定缺失值前是否去除单元格首尾空白。
        max_examples: 每列最多记录多少个缺失行号示例。
    """

    na_values: frozenset[str] = DEFAULT_NA_VALUES
    delimiter: str | None = None
    encoding: str | None = None
    has_header: bool = True
    trim_whitespace: bool = True
    max_examples: int = 5

    def __post_init__(self) -> None:
        object.__setattr__(self, "na_values", frozenset(self.na_values))
        if self.max_examples < 0:
            raise ValueError("max_examples 不能为负数")

    def na_token_set(self) -> frozenset[str]:
        """返回用于比较的缺失标记集合（统一小写，空单元格始终在内）。"""
        tokens = {token.strip().lower() for token in self.na_values}
        tokens.add("")
        return frozenset(tokens)

    def to_dict(self) -> dict:
        """转换为可 JSON 序列化的字典。"""
        return {
            "na_values": sorted(self.na_values),
            "has_header": self.has_header,
            "trim_whitespace": self.trim_whitespace,
            "max_examples": self.max_examples,
        }


def parse_na_values(raw: str) -> frozenset[str]:
    """把 CLI 传入的逗号分隔字符串解析为缺失标记集合。

    ``--na-values na,null`` 表示除空单元格外，只有 ``na`` 和 ``null`` 也算缺失；
    传入空字符串则表示只额外识别空单元格（等价于 ``--no-extra-na``）。
    """
    tokens = []
    for item in raw.split(","):
        token = item.strip()
        if token:
            tokens.append(token)
    return frozenset(tokens)

"""CSV 数据质量检查核心逻辑。

本模块提供两类检查：

1. **缺失值检查**：逐列统计缺失单元格数量、缺失率以及缺失值的原始写法分布。
2. **重复行检查**：统计“完整重复行”数量（同一组完全相同的行中，除首次出现之外的
   行数），并给出重复行所在的行号。

实现只依赖 Python 标准库。
"""

from __future__ import annotations

import csv
import io
import os
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable, Iterator, Sequence

from .config import DEFAULT_NA_VALUES, CheckConfig

__all__ = [
    "ColumnQuality",
    "DuplicateGroup",
    "QualityReport",
    "check_csv",
    "check_csv_rows",
    "detect_dialect",
    "read_csv_rows",
]

# csv 模块默认单字段上限 128KB，放宽一些以兼容大文本字段。
try:  # pragma: no cover - 平台相关
    csv.field_size_limit(10 * 1024 * 1024)
except OverflowError:  # pragma: no cover
    pass


@dataclass
class ColumnQuality:
    """单列的缺失值统计结果。"""

    name: str
    index: int
    total_rows: int
    missing_count: int
    missing_ratio: float
    missing_values: dict[str, int] = field(default_factory=dict)
    example_row_numbers: list[int] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """转换为可 JSON 序列化的字典。"""
        return {
            "name": self.name,
            "index": self.index,
            "total_rows": self.total_rows,
            "missing_count": self.missing_count,
            "missing_ratio": round(self.missing_ratio, 6),
            "missing_values": dict(sorted(self.missing_values.items())),
            "example_row_numbers": list(self.example_row_numbers),
        }


@dataclass
class DuplicateGroup:
    """一组完全重复的行。"""

    row_numbers: list[int]
    values: list[str]
    occurrences: int

    @property
    def duplicate_count(self) -> int:
        """除首次出现之外的重复行数。"""
        return self.occurrences - 1

    def to_dict(self) -> dict[str, Any]:
        """转换为可 JSON 序列化的字典。"""
        return {
            "occurrences": self.occurrences,
            "duplicate_count": self.duplicate_count,
            "row_numbers": list(self.row_numbers),
            "values": list(self.values),
        }


@dataclass
class QualityReport:
    """整体检查报告。"""

    file_path: str
    total_rows: int
    column_count: int
    columns: list[ColumnQuality] = field(default_factory=list)
    duplicate_groups: list[DuplicateGroup] = field(default_factory=list)
    duplicate_row_count: int = 0
    unique_row_count: int = 0
    generated_at: str = ""
    delimiter: str = ","
    encoding: str = "utf-8"
    warnings: list[str] = field(default_factory=list)

    @property
    def total_missing(self) -> int:
        """所有列的缺失单元格总数。"""
        return sum(column.missing_count for column in self.columns)

    @property
    def columns_with_missing(self) -> int:
        """存在至少一个缺失值的列数。"""
        return sum(1 for column in self.columns if column.missing_count > 0)

    def to_dict(self) -> dict[str, Any]:
        """转换为可 JSON 序列化的字典。"""
        return {
            "file": self.file_path,
            "generated_at": self.generated_at,
            "total_rows": self.total_rows,
            "column_count": self.column_count,
            "total_missing_values": self.total_missing,
            "columns_with_missing": self.columns_with_missing,
            "duplicate_row_count": self.duplicate_row_count,
            "duplicate_group_count": len(self.duplicate_groups),
            "unique_row_count": self.unique_row_count,
            "columns": [column.to_dict() for column in self.columns],
            "duplicate_groups": [group.to_dict() for group in self.duplicate_groups],
            "warnings": list(self.warnings),
        }

    def to_json(self, indent: int = 2, ensure_ascii: bool = False) -> str:
        """把报告序列化为 JSON 字符串。"""
        import json

        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=ensure_ascii)


def _normalize(value: str, config: CheckConfig) -> str:
    """按配置规范化单元格内容。"""
    return value.strip() if config.trim_whitespace else value


def _is_missing(value: str, tokens: frozenset[str], config: CheckConfig) -> bool:
    """判断单个单元格是否缺失。"""
    normalized = _normalize(value, config)
    if normalized == "":
        return True
    return normalized.lower() in tokens


def read_csv_rows(path: str | os.PathLike[str], config: CheckConfig | None = None) -> tuple[list[str], list[list[str]], str, str]:
    """读取 CSV，返回 ``(表头, 数据行, 分隔符, 编码)``。

    读取失败时会抛出 ``FileNotFoundError`` 或 ``UnicodeDecodeError``。
    """
    config = config or CheckConfig()
    path = os.fspath(path)

    with open(path, "rb") as handle:
        raw = handle.read()

    encoding = config.encoding or _detect_encoding(raw)
    delimiter = config.delimiter or _detect_delimiter(raw, encoding)

    text = raw.decode(encoding)
    reader = csv.reader(io.StringIO(text, newline=""), delimiter=delimiter)

    rows = [row for row in reader]
    if config.has_header:
        header = rows[0] if rows else []
        data_rows = rows[1:]
    else:
        header = []
        data_rows = rows

    return header, data_rows, delimiter, encoding


def _detect_encoding(raw: bytes) -> str:
    """尝试常见编码解码，返回第一个成功的编码。"""
    for encoding in ("utf-8-sig", "utf-8", "gb18030", "latin-1"):
        try:
            raw.decode(encoding)
        except UnicodeDecodeError:
            continue
        return encoding
    return "latin-1"  # pragma: no cover - latin-1 永不失败


def _detect_delimiter(raw: bytes, encoding: str) -> str:
    """嗅探 CSV 分隔符，失败时回退到逗号。"""
    sample = raw.decode(encoding, errors="replace")[:8192]
    if not sample.strip():
        return ","
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        return dialect.delimiter
    except csv.Error:
        # 回退：统计首个非空行里出现最多的候选分隔符。
        first_line = next((line for line in sample.splitlines() if line.strip()), "")
        best, best_count = ",", 0
        for candidate in (",", ";", "\t", "|"):
            count = first_line.count(candidate)
            if count > best_count:
                best, best_count = candidate, count
        return best


def check_csv_rows(
    header: Sequence[str],
    data_rows: Sequence[Sequence[str]],
    config: CheckConfig | None = None,
    file_path: str = "<memory>",
) -> QualityReport:
    """对已在内存中的表头与数据行执行检查。

    这是 :func:`check_csv` 的纯计算内核，方便单元测试直接喂数据。
    """
    config = config or CheckConfig()
    tokens = config.na_token_set()

    width = len(header) if header else (max((len(r) for r in data_rows), default=0))
    if width == 0:
        width = 0

    column_names = list(header)
    if not column_names and width:
        column_names = [f"column_{i + 1}" for i in range(width)]
    # 表头中的空列名回退为 column_N，避免报告里出现无法区分的键。
    column_names = [
        (name.strip() if name and name.strip() else f"column_{i + 1}")
        for i, name in enumerate(column_names)
    ]

    missing_counts = [0] * width
    missing_value_counter: list[Counter[str]] = [Counter() for _ in range(width)]
    example_rows: list[list[int]] = [[] for _ in range(width)]

    seen: dict[tuple[str, ...], list[int]] = defaultdict(list)
    group_order: list[tuple[str, ...]] = []

    for row_number, row in enumerate(data_rows, start=1):
        padded = list(row) + [""] * max(0, width - len(row))
        values = padded[:width]
        for index, value in enumerate(values):
            if _is_missing(value, tokens, config):
                missing_counts[index] += 1
                normalized = _normalize(value, config)
                label = normalized if normalized else "<empty>"
                missing_value_counter[index][label] += 1
                if len(example_rows[index]) < config.max_examples:
                    example_rows[index].append(row_number)
        # 用原始行（而非补齐后的行）做键，保证“完全重复”指字段逐一相等。
        key = tuple(_normalize(value, config) for value in row)
        if key not in seen:
            group_order.append(key)
        seen[key].append(row_number)

    columns = [
        ColumnQuality(
            name=column_names[index],
            index=index,
            total_rows=len(data_rows),
            missing_count=missing_counts[index],
            missing_ratio=(missing_counts[index] / len(data_rows)) if data_rows else 0.0,
            missing_values=dict(missing_value_counter[index]),
            example_row_numbers=example_rows[index],
        )
        for index in range(width)
    ]

    duplicate_groups: list[DuplicateGroup] = []
    duplicate_row_count = 0
    for key in group_order:
        row_numbers = seen[key]
        if len(row_numbers) > 1:
            duplicate_row_count += len(row_numbers) - 1
            duplicate_groups.append(
                DuplicateGroup(
                    row_numbers=list(row_numbers),
                    values=list(key),
                    occurrences=len(row_numbers),
                )
            )

    return QualityReport(
        file_path=file_path,
        total_rows=len(data_rows),
        column_count=width,
        columns=columns,
        duplicate_groups=duplicate_groups,
        duplicate_row_count=duplicate_row_count,
        unique_row_count=len(seen),
        generated_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    )


def check_csv(path: str | os.PathLike[str], config: CheckConfig | None = None) -> QualityReport:
    """检查指定 CSV 文件并返回 :class:`QualityReport`。

    Args:
        path: CSV 文件路径。
        config: 可选的检查配置；为 ``None`` 时使用默认配置。

    Raises:
        FileNotFoundError: 路径不存在或不是普通文件。
    """
    config = config or CheckConfig()
    file_path = os.fspath(path)
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"CSV 文件不存在: {file_path}")
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"路径不是普通文件: {file_path}")

    header, data_rows, delimiter, encoding = read_csv_rows(file_path, config)
    report = check_csv_rows(header, data_rows, config, file_path=file_path)
    report.delimiter = delimiter
    report.encoding = encoding

    if config.has_header and not header:
        report.warnings.append("文件为空或没有表头行。")
    if any(len(row) != len(header) for row in data_rows if header):
        report.warnings.append("存在字段数与表头不一致的行，已按空字符串补齐。")
    return report

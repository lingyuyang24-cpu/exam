"""csv-qc：一个只依赖标准库的 CSV 数据质量检查工具。

主要入口：

- :func:`csv_qc.check_csv` —— 检查 CSV 文件，返回 :class:`QualityReport`。
- :func:`csv_qc.main` —— 命令行入口。
"""

from .checker import (
    ColumnQuality,
    DuplicateGroup,
    QualityReport,
    check_csv,
    check_csv_rows,
    detect_dialect,
    read_csv_rows,
)
from .config import DEFAULT_NA_VALUES, CheckConfig, parse_na_values

__version__ = "1.0.0"

__all__ = [
    "ColumnQuality",
    "DuplicateGroup",
    "QualityReport",
    "CheckConfig",
    "DEFAULT_NA_VALUES",
    "check_csv",
    "check_csv_rows",
    "detect_dialect",
    "read_csv_rows",
    "parse_na_values",
    "main",
    "__version__",
]


def main(argv=None) -> int:
    """命令行入口的便捷包装。"""
    from .cli import main as _main

    return _main(argv)

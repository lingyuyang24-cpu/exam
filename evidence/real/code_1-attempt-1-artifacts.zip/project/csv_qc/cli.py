"""命令行入口：检查 CSV 并输出 JSON 报告。"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

from .checker import check_csv
from .config import DEFAULT_NA_VALUES, CheckConfig, parse_na_values


def build_parser() -> argparse.ArgumentParser:
    """构建命令行参数解析器。"""
    parser = argparse.ArgumentParser(
        prog="csv-qc",
        description="检查 CSV 的缺失值与完整重复行，输出 JSON 报告。",
    )
    parser.add_argument("csv_path", help="待检查的 CSV 文件路径")
    parser.add_argument(
        "-o",
        "--output",
        default="-",
        help="JSON 报告输出路径，“-” 表示打印到标准输出（默认）",
    )
    parser.add_argument(
        "--encoding",
        default=None,
        help="指定文件编码，默认自动探测（utf-8-sig/utf-8/gb18030/latin-1）",
    )
    parser.add_argument(
        "--delimiter",
        default=None,
        help="指定字段分隔符，默认自动嗅探",
    )
    parser.add_argument(
        "--na-values",
        default=None,
        help=(
            "额外视为缺失值的标记，逗号分隔（比较时忽略大小写）。"
            f"默认：{','.join(sorted(DEFAULT_NA_VALUES - {''}))}。空单元格始终计为缺失"
        ),
    )
    parser.add_argument(
        "--no-header",
        action="store_true",
        help="首行不是表头时使用此参数",
    )
    parser.add_argument(
        "--keep-whitespace",
        action="store_true",
        help="判定缺失值时不去除单元格首尾空白",
    )
    parser.add_argument(
        "--max-examples",
        type=int,
        default=5,
        help="每列最多记录的缺失行号示例数量（默认 5）",
    )
    parser.add_argument(
        "--indent",
        type=int,
        default=2,
        help="JSON 缩进空格数，0 表示不缩进（默认 2）",
    )
    return parser


def _build_config(args: argparse.Namespace) -> CheckConfig:
    """把命令行参数转换为 :class:`CheckConfig`。"""
    if args.na_values is None:
        na_values = DEFAULT_NA_VALUES
    else:
        na_values = parse_na_values(args.na_values)
    return CheckConfig(
        na_values=na_values,
        delimiter=args.delimiter,
        encoding=args.encoding,
        has_header=not args.no_header,
        trim_whitespace=not args.keep_whitespace,
        max_examples=args.max_examples,
    )


def main(argv: Sequence[str] | None = None) -> int:
    """命令行主入口，返回进程退出码。"""
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        config = _build_config(args)
        report = check_csv(args.csv_path, config)
    except FileNotFoundError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2
    except ValueError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2

    indent = args.indent if args.indent > 0 else None
    payload = json.dumps(report.to_dict(), indent=indent, ensure_ascii=False)

    if args.output == "-":
        print(payload)
    else:
        try:
            with open(args.output, "w", encoding="utf-8") as handle:
                handle.write(payload + "\n")
        except OSError as exc:
            print(f"错误: 无法写入报告文件 {args.output}: {exc}", file=sys.stderr)
            return 2
        print(
            f"报告已写入 {args.output}: "
            f"{report.total_rows} 行, {report.column_count} 列, "
            f"缺失单元格 {report.total_missing}, 重复行 {report.duplicate_row_count}"
        )
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())

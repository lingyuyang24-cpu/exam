#!/usr/bin/env python3
"""十月销售数据分析（第二版）。

口径：仅统计状态为“已完成”的订单，订单金额 = 数量 * 单价（不含税、成本、退款等未提供信息）。
口径开关：STATUS_SCOPE 设为 "已完成" 只统计已完成订单；设为 None 则统计全部订单。
输入：uploads/92e6e778_sales.csv, uploads/5821dd10_meeting_notes.md
输出：outputs/summary.csv（region,total_sales）, outputs/report.md（一页管理层摘要）,
      outputs/report_detail.md（支撑明细）
"""

from __future__ import annotations

import csv
import re
from collections import OrderedDict, defaultdict
from datetime import date
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"

SALES_CSV = UPLOADS / "92e6e778_sales.csv"
NOTES_MD = UPLOADS / "5821dd10_meeting_notes.md"
SUMMARY_CSV = OUTPUTS / "summary.csv"
REPORT_MD = OUTPUTS / "report.md"
DETAIL_MD = OUTPUTS / "report_detail.md"

AMOUNT_FORMULA = "订单金额 = 数量(quantity) × 单价(unit_price)"
STATUS_SCOPE = "已完成"          # 只统计该状态的订单；None 表示统计全部订单


def caliber_text():
    """当前口径的文字说明（随 STATUS_SCOPE 变化）。"""
    if STATUS_SCOPE is None:
        return "全部订单（含已取消、待付款），不做状态过滤"
    return f"仅统计状态为“{STATUS_SCOPE}”的订单，已取消与待付款订单不计入"


def caliber_short():
    if STATUS_SCOPE is None:
        return "全部订单"
    return f"仅“{STATUS_SCOPE}”订单"


def in_scope(status):
    """该状态的订单是否计入当前口径。"""
    return STATUS_SCOPE is None or status == STATUS_SCOPE


def scope_label():
    if STATUS_SCOPE is None:
        return "计入订单金额"
    if STATUS_SCOPE == "已完成":
        return "已完成订单金额"
    return f"“{STATUS_SCOPE}”订单金额"


# ---------- 通用工具 ----------

def fmt_amount(value: float) -> str:
    """整数金额不带小数点，否则保留两位。"""
    if float(value).is_integer():
        return str(int(value))
    return f"{value:.2f}"


def fmt_pct(part: float, whole: float) -> str:
    if not whole:
        return "—"
    return f"{part / whole * 100:.1f}%"


def md_table(headers, rows) -> str:
    lines = ["| " + " | ".join(headers) + " |",
             "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(str(c) for c in row) + " |")
    return "\n".join(lines)


# ---------- 1. 读取并校验销售数据 ----------

def load_orders(path: Path):
    """读取订单并做基础校验；返回 (orders, checks)。"""
    orders = []
    checks = []
    with path.open(encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        required = ["order_id", "date", "region", "product", "quantity", "unit_price", "status"]
        missing = [c for c in required if c not in (reader.fieldnames or [])]
        if missing:
            raise SystemExit(f"销售数据缺少必要列: {missing}")
        checks.append(f"表头完整，包含 {len(required)} 个必要字段: {', '.join(required)}")
        for lineno, row in enumerate(reader, start=2):
            order = {
                "order_id": (row["order_id"] or "").strip(),
                "date": (row["date"] or "").strip(),
                "region": (row["region"] or "").strip(),
                "product": (row["product"] or "").strip(),
                "quantity": int(row["quantity"]),
                "unit_price": float(row["unit_price"]),
                "status": (row["status"] or "").strip(),
                "line": lineno,
            }
            for key in ("order_id", "date", "region", "product", "status"):
                if not order[key]:
                    raise SystemExit(f"第 {lineno} 行字段 {key} 为空")
            order["amount"] = order["quantity"] * order["unit_price"]
            orders.append(order)

    ids = [o["order_id"] for o in orders]
    dupes = sorted({i for i in ids if ids.count(i) > 1})
    checks.append(f"订单行数 {len(orders)} 条；order_id 唯一: {'是' if not dupes else '否 ' + str(dupes)}")
    dates = sorted(o["date"] for o in orders)
    checks.append(f"订单日期区间 {dates[0]} 至 {dates[-1]}（日期格式 YYYY-MM-DD）")
    checks.append(f"金额字段由 {AMOUNT_FORMULA} 计算，未做任何人工调整")
    return orders, checks


# ---------- 2. 汇总计算 ----------

def aggregate(orders):
    """按区域 / 产品 / 状态汇总金额与订单数。"""
    region = defaultdict(lambda: {"amount": 0.0, "count": 0, "qty": 0})
    product = defaultdict(lambda: {"amount": 0.0, "count": 0, "qty": 0})
    status = defaultdict(lambda: {"amount": 0.0, "count": 0, "qty": 0})
    for o in orders:
        for bucket, key in ((region, o["region"]), (product, o["product"]), (status, o["status"])):
            bucket[key]["amount"] += o["amount"]
            bucket[key]["count"] += 1
            bucket[key]["qty"] += o["quantity"]
    return region, product, status


def sort_rows(bucket):
    """按金额降序排序，金额相同按名称升序，保证结果稳定可复现。"""
    return sorted(bucket.items(), key=lambda kv: (-kv[1]["amount"], kv[0]))


def region_product_breakdown(orders, region_name):
    """某区域的产品金额构成。"""
    agg = defaultdict(lambda: {"amount": 0.0, "count": 0, "qty": 0})
    for o in orders:
        if o["region"] == region_name:
            agg[o["product"]]["amount"] += o["amount"]
            agg[o["product"]]["count"] += 1
            agg[o["product"]]["qty"] += o["quantity"]
    return sort_rows(agg)


def region_non_completed(orders, region_name, done_status="已完成"):
    """某区域非“已完成”订单的金额、订单数与明细。"""
    rows = [o for o in orders
            if o["region"] == region_name and o["status"] != done_status]
    amount = sum(o["amount"] for o in rows)
    detail = "、".join(f"{o['order_id']}（{fmt_amount(o['amount'])}，{o['status']}）" for o in rows)
    return amount, len(rows), detail


def cancelled_consistency(sp, orders, products):
    """核对发言人提到的产品与该区域“已取消”订单的产品是否一致。

    返回 (提示语, 待确认问题条目)；一致或无法判断时返回空字符串。
    """
    if not sp.get("region") or "取消" not in sp["statement"]:
        return "", None
    cancelled = [o for o in orders
                 if o["region"] == sp["region"] and o["status"] == "已取消"]
    if not cancelled:
        return "", None
    mentioned = [name for name in products if name in sp["statement"]]
    actual = sorted({o["product"] for o in cancelled})
    if mentioned and not set(mentioned) & set(actual):
        detail = "、".join(f"{o['order_id']}（{o['product']}，{fmt_amount(o['amount'])}）"
                           for o in cancelled)
        msg = (f"记录提到“{'、'.join(mentioned)}”，但该区域已取消订单为 {detail}，"
               "记录表述与数据不一致，需核对")
        return msg, msg
    return "", None


def contrast_note(statement):
    """根据会议记录原文中的关键词给出可核对性说明（不引入外部推断）。"""
    notes = []
    if "库存" in statement:
        notes.append("记录提到库存，但材料未提供库存余额，无法核对")
    if "取消" in statement or "待付款" in statement or "未付款" in statement:
        notes.append("记录提到取消/待付款订单，其金额见左列；本版口径 A 未剔除，口径 B 已作对照")
    if "补货" in statement or "区域销售额" in statement:
        notes.append("记录要求核对区域销售额，见第二节")
    if "口径" in statement:
        notes.append("记录要求说明统计口径，见第一节")
    if "成本" in statement or "税费" in statement or "退款" in statement:
        notes.append("记录说明无税费/成本/退款数据，本报告未做相关推算")
    if not notes:
        notes.append("记录表述与本次汇总指标无直接可核对项")
    return "；".join(notes)


# ---------- 3. 解析会议记录 ----------

TODO_RE = re.compile(r"^(.+?)在\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日前\s*(.+)$")
SPEAKER_RE = re.compile(r"^(.+?)负责人(.+?)[:：](.+)$")


def parse_notes(path: Path, regions):
    """从会议记录中提取发言人观点、待办与待确认事项。"""
    text = path.read_text(encoding="utf-8")
    meta = {"title": "", "date": "", "disclaimer": ""}
    speakers, todos, opens = [], [], []

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("# "):
            meta["title"] = line[2:].strip()
            continue
        if line.startswith("会议日期"):
            # 该行形如 "会议日期：2026-10-15。以下均为演示用虚构数据。"
            after = line.split("：", 1)[1].strip()
            segs = [seg.strip() for seg in after.split("。") if seg.strip()]
            if segs:
                meta["date"] = segs[0]
            if len(segs) > 1:
                meta["disclaimer"] = "。".join(segs[1:])
            continue
        if line.startswith("以下均为"):
            meta["disclaimer"] = line.lstrip("- ").strip()
            continue
        if not line.startswith("- "):
            continue
        body = line[2:].strip()

        if body.startswith("待办："):
            block = body[len("待办："):].strip().rstrip("。")
            for chunk in block.split("；"):
                chunk = chunk.strip()
                if not chunk:
                    continue
                m = TODO_RE.match(chunk)
                if m:
                    owner, month, day, task = m.groups()
                    todos.append({
                        "owner": owner.strip(),
                        "deadline": f"2026-{int(month):02d}-{int(day):02d}",
                        "task": task.strip(),
                    })
                else:
                    todos.append({"owner": "未标注", "deadline": "未标注", "task": chunk})
            continue

        if body.startswith("尚待确认："):
            block = body[len("尚待确认："):].strip().rstrip("。")
            parts = [p.strip() for p in block.split("，") if p.strip()]
            items = [i for p in parts[:1] for i in p.split("、") if i]
            note = parts[1] if len(parts) > 1 else ""
            opens.append({"items": items, "note": note})
            continue

        m = SPEAKER_RE.match(body)
        if m:
            role_desc, name, statement = (g.strip() for g in m.groups())
            speakers.append({
                "region": role_desc if role_desc in regions else "",
                "dept": role_desc if role_desc not in regions else "",
                "name": name,
                "statement": statement,
            })
        else:
            speakers.append({"region": "", "dept": "", "name": "", "statement": body})

    return meta, speakers, todos, opens


# ---------- 4. 输出 summary.csv ----------

def write_summary_csv(region_bucket, path: Path):
    rows = sort_rows(region_bucket)
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh, lineterminator="\n")
        writer.writerow(["region", "total_sales"])
        for name, agg in rows:
            writer.writerow([name, fmt_amount(agg["amount"])])
    return rows


# ---------- 5. 生成报告 ----------

def build_exec_summary(scope_orders, all_orders, meta, speakers, todos, opens):
    """一页管理层摘要：总金额、区域金额、重要结论、负责人与期限。"""
    region, product, _status = aggregate(scope_orders)
    region_all, product_all, _ = aggregate(all_orders)
    total = sum(o["amount"] for o in scope_orders)
    all_total = sum(o["amount"] for o in all_orders)
    excluded = [o for o in all_orders if not in_scope(o["status"])]
    excluded_amount = sum(o["amount"] for o in excluded)
    today = date.today()

    region_rows = sort_rows(region)
    product_rows = sort_rows(product)
    region_names_all = [n for n, _ in sort_rows(region_all)]
    product_names_all = [n for n, _ in sort_rows(product_all)]

    # ---------- 重要结论（全部由数据计算得出） ----------
    concl = []

    concl.append(
        f"**{scope_label()} {fmt_amount(total)}**（{len(scope_orders)} 单、"
        f"数量 {sum(o['quantity'] for o in scope_orders)} 件），"
        f"占全部 {len(all_orders)} 单订单金额 {fmt_amount(all_total)} 的 {fmt_pct(total, all_total)}；"
        f"已取消与待付款 {len(excluded)} 单共 {fmt_amount(excluded_amount)} 未计入。"
    )

    top_r, top_r_agg = region_rows[0]
    top_r_amt = top_r_agg["amount"]
    if region_names_all[0] != top_r:
        old_rank = region_names_all.index(top_r) + 1
        rank_note = f"，较全部订单口径的第 {old_rank} 名升至第 1 名"
    else:
        rank_note = "，与全部订单口径排名一致"
    concl.append(
        f"**区域金额**：{top_r} {fmt_amount(top_r_amt)}（{top_r_agg['count']} 单）居首{rank_note}；"
        + "；".join(f"{n} {fmt_amount(a['amount'])}（{a['count']} 单）" for n, a in region_rows[1:])
        + "。"
    )

    top_p, top_p_agg = product_rows[0]
    top_p_amt = top_p_agg["amount"]
    drop_note = ""
    now_names = [n for n, _ in product_rows]
    for name in now_names:
        all_rank = product_names_all.index(name) + 1
        now_rank = now_names.index(name) + 1
        if all_rank < now_rank:
            ex = [o for o in excluded if o["product"] == name]
            drop_note = (f"口径变化：{name}由全部订单口径第 {all_rank} 名降至第 {now_rank} 名，"
                         f"因其 {len(ex)} 单非“{STATUS_SCOPE}”订单 "
                         f"{fmt_amount(sum(o['amount'] for o in ex))} 未计入。")
            break
    concl.append(
        f"**产品结构**：{top_p} {fmt_amount(top_p_amt)} 居首；"
        + "；".join(f"{n} {fmt_amount(a['amount'])}" for n, a in product_rows[1:])
        + "。" + drop_note
    )

    focus = []
    for sp in speakers:
        if not sp["region"]:
            continue
        rp = region_product_breakdown(scope_orders, sp["region"])
        if not rp:
            continue
        pname, pagg = rp[0]
        focus.append(f"{sp['region']}以{pname}为主（{fmt_amount(pagg['amount'])}，"
                     f"占该区域 {fmt_pct(pagg['amount'], region[sp['region']]['amount'])}）")
    if focus:
        concl.append("**区域主力产品**：" + "；".join(focus) + "。")

    overdue = []
    for t in todos:
        if t["deadline"] != "未标注" and date.fromisoformat(t["deadline"]) < today:
            overdue.append(t)
    concl.append(
        f"**待办进度**：{len(todos)} 项待办中 {len(overdue)} 项截止日已过（截至 {today.isoformat()}），"
        "材料未记录完成情况，需向负责人逐一确认。"
    )

    # ---------- 组装 ----------
    parts = []
    parts.append("# 十月销售分析摘要（管理层版）\n")
    parts.append(
        f"- 统计区间：{all_orders[0]['date']} 至 {all_orders[-1]['date']}　|　"
        f"统计口径：{caliber_short()}　|　生成日期：{today.isoformat()}\n"
        f"- 数据来源：`uploads/92e6e778_sales.csv`、`uploads/5821dd10_meeting_notes.md`；"
        f"明细见 `outputs/report_detail.md`，脚本见 `project/analyze_sales.py`\n"
    )

    parts.append("\n## 关键数字\n")
    parts.append(md_table(
        ["指标", "数值"],
        [
            [scope_label(), fmt_amount(total)],
            ["计入订单数", f"{len(scope_orders)} 单（数量 {sum(o['quantity'] for o in scope_orders)} 件）"],
            ["覆盖区域", "、".join(n for n, _ in region_rows)],
            ["未计入订单", (f"已取消/待付款 {len(excluded)} 单，合计 {fmt_amount(excluded_amount)}"
                          f"（占全部订单金额 {fmt_pct(excluded_amount, all_total)}）")
                         if excluded else "无（全部订单均计入）"],
        ]))

    parts.append("\n## 区域金额\n")
    parts.append(md_table(
        ["区域", "计入订单数", "计入金额", "占计入金额", "未计入金额"],
        [[name, agg["count"], fmt_amount(agg["amount"]),
          fmt_pct(agg["amount"], total),
          fmt_amount(sum(o["amount"] for o in excluded if o["region"] == name))]
         for name, agg in region_rows]))
    parts.append(f"\n合计：{len(scope_orders)} 单，{fmt_amount(total)}。\n")

    parts.append("\n## 重要结论\n")
    for i, c in enumerate(concl, 1):
        parts.append(f"{i}. {c}\n")

    parts.append("\n## 待办、负责人与期限\n")
    if todos:
        owner_region = {s["name"]: s["region"] for s in speakers if s["name"]}
        rows = []
        for t in todos:
            if t["deadline"] != "未标注":
                dl = date.fromisoformat(t["deadline"])
                state = "已过期" if dl < today else "未到期"
            else:
                state = "未标注"
            rows.append([t["owner"], owner_region.get(t["owner"], "—"), t["deadline"], state, t["task"]])
        parts.append(md_table(["负责人", "负责区域", "截止日期", "状态", "事项"], rows))
    else:
        parts.append("会议记录中未提取到待办事项。\n")

    parts.append("\n## 口径与待确认\n")
    parts.append(
        f"- **口径**：{caliber_text()}；金额 = 数量 × 单价。"
        "材料无税费、成本、退款字段，故为订单金额，不等于利润。\n"
        f"- **待确认**：取消原因、利润率、库存余额在本材料中不可得，报告不做推算；"
        "会议记录亦未就“已取消/待付款是否计入已实现收入”形成书面结论，本版按该口径出数。\n"
    )
    return "\n".join(parts)


def build_detail_report(scope_orders, all_orders, checks, meta, speakers, todos, opens):
    """明细报告：状态、区域×产品矩阵、逐单明细、校验与待确认（支撑摘要数字）。"""
    region, product, status = aggregate(scope_orders)
    _r_all, product_all, status_all = aggregate(all_orders)
    total = sum(o["amount"] for o in scope_orders)
    all_total = sum(o["amount"] for o in all_orders)
    excluded = [o for o in all_orders if o["status"] != STATUS_SCOPE]

    parts = []
    parts.append("# 十月销售分析明细（支撑报告）\n")
    parts.append(
        f"- 统计口径：{caliber_text()}；金额 = 数量 × 单价\n"
        f"- 来源：`uploads/92e6e778_sales.csv`、`uploads/5821dd10_meeting_notes.md`\n"
        f"- 摘要见 `outputs/report.md`，区域汇总见 `outputs/summary.csv`\n"
    )

    parts.append("\n## 一、状态分布（全部订单，标注是否计入）\n")
    parts.append(md_table(
        ["订单状态", "订单数", "订单金额", "是否计入本版口径"],
        [[name, agg["count"], fmt_amount(agg["amount"]),
          "计入" if in_scope(name) else "不计入"]
         for name, agg in sort_rows(status_all)]))
    parts.append(
        f"\n计入合计 {fmt_amount(total)}（{len(scope_orders)} 单）；"
        f"未计入 {fmt_amount(all_total - total)}（{len(excluded)} 单）。\n"
    )

    parts.append("\n## 二、产品金额（本版口径）\n")
    parts.append(md_table(
        ["排名", "产品", "订单数", "数量合计", "金额", "占比"],
        [[i, name, agg["count"], agg["qty"], fmt_amount(agg["amount"]),
          fmt_pct(agg["amount"], total)]
         for i, (name, agg) in enumerate(sort_rows(product), 1)]))

    parts.append("\n## 三、区域 × 产品矩阵（本版口径）\n")
    prod_order = [name for name, _ in sort_rows(product)]
    matrix_rows = []
    for rname, ragg in sort_rows(region):
        cells = []
        for pname in prod_order:
            cell = [o for o in scope_orders if o["region"] == rname and o["product"] == pname]
            cells.append(fmt_amount(sum(o["amount"] for o in cell)) if cell else "—")
        matrix_rows.append([rname] + cells + [fmt_amount(ragg["amount"])])
    parts.append(md_table(["区域"] + prod_order + ["合计"], matrix_rows))

    parts.append("\n## 四、逐单明细\n")
    parts.append(md_table(
        ["订单号", "日期", "区域", "产品", "数量", "单价", "订单金额", "状态", "是否计入"],
        [[o["order_id"], o["date"], o["region"], o["product"], o["quantity"],
          fmt_amount(o["unit_price"]), fmt_amount(o["amount"]), o["status"],
          "计入" if in_scope(o["status"]) else "不计入"]
         for o in all_orders]))

    parts.append("\n## 五、会议关注点与数据核对\n")
    prod_names = [name for name, _ in sort_rows(product_all)]
    rows = []
    for sp in speakers:
        if not sp["region"]:
            rows.append([sp["name"] or "—", sp["dept"] or "—", "—", contrast_note(sp["statement"])])
            continue
        rp = region_product_breakdown(scope_orders, sp["region"])
        comp = "；".join(f"{n} {fmt_amount(a['amount'])}（{a['count']} 单）" for n, a in rp)
        rows.append([sp["name"] or "—", sp["region"],
                     f"区域金额 {fmt_amount(region[sp['region']]['amount'])}；{comp}",
                     contrast_note(sp["statement"])])
    parts.append(md_table(["发言人", "区域", "数据核对结果", "与记录表述的对照"], rows))

    parts.append("\n## 六、待确认问题\n")
    open_rows = []
    for blk in opens:
        for item in blk["items"]:
            open_rows.append([item, blk["note"] or "会议记录未说明"])
    for sp in speakers:
        inc_msg, inc_row = cancelled_consistency(sp, all_orders, prod_names)
        if inc_row:
            open_rows.append([f"记录表述与数据不一致（{sp['name']}/{sp['region']}）", inc_msg])
    parts.append(md_table(["待确认问题", "来源与说明"], open_rows))
    parts.append(
        "\n> 利润、利润率与订单取消原因在本材料中不可得：数据无成本/税费/退款字段，"
        "会议记录未记载取消原因，故不作推算。\n"
    )

    parts.append("\n## 七、数据校验与限制\n")
    parts.append("\n".join(f"- {c}" for c in checks))
    parts.append(
        f"\n- 本版计入 {len(scope_orders)} 单、{fmt_amount(total)}；"
        f"全部订单 {len(all_orders)} 单、{fmt_amount(all_total)}。\n"
        "- 样本仅 12 条订单、单一月份，占比与排名对个别订单敏感，不做趋势推断。\n"
        "- 金额为订单金额，不含税费、运费、成本与退款，不代表利润。\n"
    )
    return "\n".join(parts)


# ---------- 主流程 ----------

def main():
    OUTPUTS.mkdir(parents=True, exist_ok=True)

    all_orders, checks = load_orders(SALES_CSV)
    if STATUS_SCOPE is None:
        scope_orders = list(all_orders)
    else:
        scope_orders = [o for o in all_orders if o["status"] == STATUS_SCOPE]
    if not scope_orders:
        raise SystemExit(f"口径 {STATUS_SCOPE} 下没有任何订单，无法出数")

    region, product, status = aggregate(scope_orders)
    meta, speakers, todos, opens = parse_notes(NOTES_MD, set(region))

    region_rows = write_summary_csv(region, SUMMARY_CSV)
    REPORT_MD.write_text(
        build_exec_summary(scope_orders, all_orders, meta, speakers, todos, opens),
        encoding="utf-8")
    DETAIL_MD.write_text(
        build_detail_report(scope_orders, all_orders, checks, meta, speakers, todos, opens),
        encoding="utf-8")

    # 控制台核对输出
    total = sum(o["amount"] for o in scope_orders)
    all_total = sum(o["amount"] for o in all_orders)
    print(f"口径: {caliber_text()}")
    print(f"计入订单数: {len(scope_orders)} / 全部 {len(all_orders)}  "
          f"数量合计: {sum(o['quantity'] for o in scope_orders)}  金额合计: {fmt_amount(total)}")
    print(f"区域汇总 ({caliber_short()}):")
    for name, agg in region_rows:
        print(f"  {name}: {fmt_amount(agg['amount'])}  ({agg['count']} 单)")
    print("产品排名:")
    for i, (name, agg) in enumerate(sort_rows(product), 1):
        print(f"  {i}. {name}: {fmt_amount(agg['amount'])}")
    print("状态分布 (全部订单):")
    for name, agg in sort_rows(aggregate(all_orders)[2]):
        mark = "计入" if in_scope(name) else "不计入"
        print(f"  {name}: {fmt_amount(agg['amount'])}  ({agg['count']} 单, {mark})")
    print(f"交叉校验: 区域 {fmt_amount(sum(a['amount'] for a in region.values()))} / "
          f"产品 {fmt_amount(sum(a['amount'] for a in product.values()))} / "
          f"状态 {fmt_amount(sum(a['amount'] for a in status.values()))} / "
          f"逐单 {fmt_amount(total)}  (全部订单 {fmt_amount(all_total)})")
    print(f"已写出: {SUMMARY_CSV}")
    print(f"已写出: {REPORT_MD}")
    print(f"已写出: {DETAIL_MD}")


if __name__ == "__main__":
    main()

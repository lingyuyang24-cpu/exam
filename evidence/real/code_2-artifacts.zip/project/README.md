# csv-qc

只依赖 Python 标准库的 CSV 数据质量检查工具：统计**每列缺失值**与**完整重复行**，输出 JSON 报告。

## 功能

- 缺失值：逐列给出缺失数量、缺失率、缺失值写法分布（如 `NA`、`<empty>`）与示例行号。
- 重复行：字段完全相同的行归为一组，`duplicate_row_count` = 每组出现次数 − 1（首次出现不计入）。
- 自动探测编码与分隔符；字段数与表头不一致的行按空字符串补齐并在 `warnings` 提示。
- `--dedupe-output` 可把去重结果写到新文件：保留每组重复行的首个完整行，输入文件不变。

## 用法

```bash
cd project
python3 -m csv_qc examples/sample.csv                    # 打印 JSON
python3 -m csv_qc examples/sample.csv -o report.json      # 写入文件
python3 -m csv_qc data.csv --na-values "n.a,missing"      # 自定义缺失标记
python3 -m csv_qc data.csv --no-header --encoding gbk     # 无表头 / 指定编码
python3 -m csv_qc data.csv --dedupe-output clean.csv       # 另存去重结果
```

作为库使用：`from csv_qc import check_csv; report = check_csv("data.csv")`

## 报告字段

顶层：`file`、`generated_at`、`encoding`、`delimiter`、`total_rows`、`column_count`、`columns`、
`total_missing_values`、`columns_with_missing`、`unique_row_count`、`duplicate_row_count`、
`duplicate_group_count`、`duplicate_groups`、`warnings`（使用 `--dedupe-output` 时另有 `dedupe_output`）。

`columns[i]`：`name`、`index`、`missing_count`、`missing_ratio`、`missing_values`、`example_row_numbers`。
`duplicate_groups[i]`：`values`、`occurrences`、`duplicate_count`、`row_numbers`（行号从 1 起，不含表头）。

## 测试

```bash
cd project && python3 -m unittest discover -s tests -v
```

## 约定

- 空单元格始终计为缺失；默认额外识别 `na`、`n/a`、`null`、`none`、`nan`（忽略大小写），可用 `--na-values` 覆盖。
- 判定缺失前默认去除单元格首尾空白。
- 重复行按 CSV 解析后的原始字段逐一比较，空白字符不同不算重复；`--dedupe-output` 与该口径一致。
- `--dedupe-output` 拒绝写回输入文件（同路径或软/硬链接），退出码 2。

"""csv_qc 的 unittest 测试。"""

import json
import os
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from csv_qc import CheckConfig, check_csv  # noqa: E402
from csv_qc.cli import main  # noqa: E402

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class CheckCsvTest(unittest.TestCase):
    """核心检查逻辑的测试。"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def write(self, content, name="data.csv", encoding="utf-8"):
        path = os.path.join(self.tmp.name, name)
        with open(path, "w", encoding=encoding, newline="") as handle:
            handle.write(content)
        return path

    def test_missing_values_per_column(self):
        """每列缺失数量与缺失率应正确统计。"""
        path = self.write("id,name,city\n1,Alice,\n2,,Beijing\n3,Bob,\n")
        report = check_csv(path)

        self.assertEqual(report["total_rows"], 3)
        self.assertEqual(report["column_count"], 3)
        self.assertEqual([c["missing_count"] for c in report["columns"]], [0, 1, 2])
        self.assertAlmostEqual(report["columns"][2]["missing_ratio"], 2 / 3, places=5)
        self.assertEqual(report["total_missing_values"], 3)
        self.assertEqual(report["columns_with_missing"], 2)

    def test_missing_values_examples_and_kinds(self):
        """应记录缺失值写法分布与示例行号。"""
        path = self.write("a,b\nNA,1\n2,\n3,\n")
        report = check_csv(path)

        na_column = report["columns"][0]
        self.assertEqual(na_column["missing_count"], 1)
        self.assertEqual(na_column["missing_values"], {"NA": 1})
        self.assertEqual(na_column["example_row_numbers"], [1])

        empty_column = report["columns"][1]
        self.assertEqual(empty_column["missing_count"], 2)
        self.assertEqual(empty_column["missing_values"], {"<empty>": 2})
        self.assertEqual(empty_column["example_row_numbers"], [2, 3])

    def test_duplicate_rows_exclude_first_occurrence(self):
        """重复行数 = 每组出现次数 - 1，首次出现不计入。"""
        path = self.write("id,name\n1,a\n2,b\n1,a\n3,c\n1,a\n")
        report = check_csv(path)

        self.assertEqual(report["duplicate_row_count"], 2)
        self.assertEqual(report["duplicate_group_count"], 1)
        group = report["duplicate_groups"][0]
        self.assertEqual(group["occurrences"], 3)
        self.assertEqual(group["duplicate_count"], 2)
        self.assertEqual(group["row_numbers"], [1, 3, 5])
        self.assertEqual(group["values"], ["1", "a"])
        self.assertEqual(report["unique_row_count"], 3)

    def test_no_duplicates_and_no_missing(self):
        """干净文件应报告零缺失、零重复。"""
        path = self.write("id,name\n1,a\n2,b\n")
        report = check_csv(path)

        self.assertEqual(report["total_missing_values"], 0)
        self.assertEqual(report["duplicate_row_count"], 0)
        self.assertEqual(report["duplicate_group_count"], 0)
        self.assertEqual(report["unique_row_count"], 2)

    def test_custom_na_values_and_header_handling(self):
        """自定义缺失标记与无表头模式应生效。"""
        path = self.write("x,y\nNA,1\nMISSING,2\n")
        config = CheckConfig(na_values=frozenset({"missing"}))
        report = check_csv(path, config)

        self.assertEqual(report["columns"][0]["missing_count"], 1)
        self.assertEqual(report["columns"][0]["missing_values"], {"MISSING": 1})

        no_header = check_csv(path, CheckConfig(has_header=False))
        self.assertEqual(no_header["total_rows"], 3)
        self.assertEqual(no_header["columns"][0]["name"], "column_1")

    def test_missing_file_raises(self):
        """文件不存在时抛出 FileNotFoundError。"""
        with self.assertRaises(FileNotFoundError):
            check_csv(os.path.join(self.tmp.name, "nope.csv"))


class CliTest(unittest.TestCase):
    """命令行入口的测试。"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def test_cli_writes_json_file(self):
        """-o 应写出合法 JSON 文件并返回 0。"""
        path = os.path.join(self.tmp.name, "data.csv")
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("id,name\n1,a\n1,a\n2,\n")
        out = os.path.join(self.tmp.name, "report.json")

        code = main([path, "-o", out])

        self.assertEqual(code, 0)
        with open(out, encoding="utf-8") as handle:
            report = json.load(handle)
        self.assertEqual(report["duplicate_row_count"], 1)
        self.assertEqual(report["total_missing_values"], 1)

    def test_cli_missing_file_returns_error_code(self):
        """文件不存在时退出码为 2。"""
        code = main([os.path.join(self.tmp.name, "nope.csv")])
        self.assertEqual(code, 2)

    def test_module_entry_point(self):
        """python -m csv_qc 应输出 JSON 到标准输出。"""
        path = os.path.join(self.tmp.name, "data.csv")
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("id,name\n1,a\n")

        result = subprocess.run(
            [sys.executable, "-m", "csv_qc", path],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
        )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["total_rows"], 1)


if __name__ == "__main__":
    unittest.main()

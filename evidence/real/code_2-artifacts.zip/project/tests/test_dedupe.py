"""--dedupe-output 去重功能的边界测试。"""

import csv
import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from csv_qc import CheckConfig, check_csv, dedupe_csv  # noqa: E402
from csv_qc.cli import main  # noqa: E402


class DedupeTest(unittest.TestCase):
    """去重写出的测试。"""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def write(self, content, name="data.csv"):
        path = os.path.join(self.tmp.name, name)
        with open(path, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
        return path

    def read(self, path):
        with open(path, encoding="utf-8", newline="") as handle:
            return list(csv.reader(handle))

    def test_dedupe_keeps_first_occurrence_and_full_row(self):
        """去重应保留首个出现的完整行，且内容与原行一致。"""
        path = self.write("id,name,city\n1,Alice,北京\n2,Bob,上海\n1,Alice,北京\n")
        out = os.path.join(self.tmp.name, "dedup.csv")

        info = dedupe_csv(path, out)

        self.assertEqual(info["rows_written"], 2)
        self.assertEqual(info["rows_removed"], 1)
        rows = self.read(out)
        self.assertEqual(rows[0], ["id", "name", "city"])
        self.assertEqual(rows[1], ["1", "Alice", "北京"])
        self.assertEqual(rows[2], ["2", "Bob", "上海"])
        self.assertEqual(len(rows), 3)

    def test_dedupe_preserves_first_row_not_merged_values(self):
        """重复组应保留首次出现的整行，而不是各列首值拼成的行。"""
        path = self.write("a,b\nx,1\ny,2\nx,9\n")
        out = os.path.join(self.tmp.name, "dedup.csv")

        dedupe_csv(path, out)

        rows = self.read(out)
        self.assertEqual(rows[1], ["x", "1"])
        self.assertEqual(rows[2], ["y", "2"])

    def test_whitespace_different_rows_are_not_duplicates(self):
        """空白字符不同的行不算重复，应全部保留。"""
        path = self.write("id,name\n1,Alice\n1,Alice \n1, Alice\n")
        out = os.path.join(self.tmp.name, "dedup.csv")

        info = dedupe_csv(path, out)

        self.assertEqual(info["rows_written"], 3)
        self.assertEqual(info["rows_removed"], 0)
        self.assertEqual(len(self.read(out)), 4)

    def test_missing_value_still_trims_whitespace(self):
        """缺失值判断仍然去除首尾空白，与去重口径不同。"""
        path = self.write("id,name\n1,   \n2,\n")

        report = check_csv(path)

        self.assertEqual(report["columns"][1]["missing_count"], 2)
        self.assertEqual(report["duplicate_row_count"], 0)

    def test_report_duplicate_count_matches_dedupe_output(self):
        """报告的重复行数必须与去重后去掉的行数一致。"""
        path = self.write("id,name\n1,a\n1,a\n1,a\n2,b\n2,b\n3,c\n")
        out = os.path.join(self.tmp.name, "dedup.csv")

        report = check_csv(path)
        info = dedupe_csv(path, out)

        self.assertEqual(report["duplicate_row_count"], 3)
        self.assertEqual(info["rows_removed"], report["duplicate_row_count"])
        self.assertEqual(info["rows_written"], report["unique_row_count"])

    def test_input_file_is_not_modified(self):
        """去重后原始输入文件内容必须保持不变。"""
        path = self.write("id,name\n1,a\n1,a\n")
        out = os.path.join(self.tmp.name, "dedup.csv")
        with open(path, encoding="utf-8") as handle:
            before = handle.read()

        dedupe_csv(path, out)

        with open(path, encoding="utf-8") as handle:
            self.assertEqual(handle.read(), before)

    def test_refuse_write_back_to_input(self):
        """输出与输入是同一文件时应拒绝写入。"""
        path = self.write("id,name\n1,a\n1,a\n")

        with self.assertRaises(ValueError):
            dedupe_csv(path, path)

    def test_refuse_write_back_via_symlink(self):
        """输出是指向输入的软链接时同样应拒绝。"""
        path = self.write("id,name\n1,a\n1,a\n")
        link = os.path.join(self.tmp.name, "link.csv")
        os.symlink(path, link)

        with self.assertRaises(ValueError):
            dedupe_csv(path, link)

    def test_dedupe_keeps_header_and_handles_no_header(self):
        """无表头模式下去重结果不应多出表头行。"""
        path = self.write("1,a\n1,a\n2,b\n")
        out = os.path.join(self.tmp.name, "dedup.csv")

        dedupe_csv(path, out, CheckConfig(has_header=False))

        rows = self.read(out)
        self.assertEqual(rows, [["1", "a"], ["2", "b"]])

    def test_dedupe_empty_file(self):
        """空文件去重应产出空文件且不报错。"""
        path = self.write("")
        out = os.path.join(self.tmp.name, "dedup.csv")

        info = dedupe_csv(path, out)

        self.assertEqual(info["rows_written"], 0)
        self.assertEqual(info["rows_removed"], 0)
        self.assertEqual(self.read(out), [])

    def test_cli_dedupe_output_flag(self):
        """CLI 的 --dedupe-output 应写出去重文件并在报告中给出统计。"""
        path = self.write("id,name\n1,a\n1,a\n2,b\n")
        out = os.path.join(self.tmp.name, "dedup.csv")
        report_path = os.path.join(self.tmp.name, "report.json")

        code = main([path, "-o", report_path, "--dedupe-output", out])

        self.assertEqual(code, 0)
        with open(report_path, encoding="utf-8") as handle:
            report = json.load(handle)
        self.assertEqual(report["duplicate_row_count"], 1)
        self.assertEqual(report["dedupe_output"]["rows_removed"], 1)
        self.assertEqual(report["dedupe_output"]["rows_written"], 2)
        self.assertEqual(len(self.read(out)), 3)

    def test_cli_refuses_dedupe_output_over_input(self):
        """CLI 指定输出等于输入时应报错并返回非 0 退出码。"""
        path = self.write("id,name\n1,a\n1,a\n")
        with open(path, encoding="utf-8") as handle:
            before = handle.read()

        code = main([path, "--dedupe-output", path])

        self.assertEqual(code, 2)
        with open(path, encoding="utf-8") as handle:
            self.assertEqual(handle.read(), before)


if __name__ == "__main__":
    unittest.main()

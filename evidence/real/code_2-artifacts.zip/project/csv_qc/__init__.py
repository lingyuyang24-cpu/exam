"""csv-qc：只依赖标准库的 CSV 数据质量检查工具。"""

from .core import DEFAULT_NA_VALUES, CheckConfig, check_csv, check_csv_json, dedupe_csv

__version__ = "1.0.0"
__all__ = [
    "CheckConfig",
    "DEFAULT_NA_VALUES",
    "check_csv",
    "check_csv_json",
    "dedupe_csv",
    "__version__",
]

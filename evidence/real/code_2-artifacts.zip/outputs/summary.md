# CSV 数据质量检查工具 — 交付说明

## 交付内容

| 文件 | 说明 |
| --- | --- |
| `project/csv_qc/core.py` | 核心检查逻辑：缺失值统计 + 完整重复行统计 + `dedupe_csv` 去重写出（210 行） |
| `project/csv_qc/cli.py` | 命令行入口，含 `--dedupe-output`（105 行） |
| `project/csv_qc/__init__.py` / `__main__.py` | 包导出与 `python -m csv_qc` 支持 |
| `project/tests/test_csv_qc.py` | 9 项 unittest（146 行） |
| `project/tests/test_dedupe.py` | 12 项去重边界 unittest（170 行） |
| `project/README.md` | 使用说明（45 行） |
| `project/examples/sample.csv` | 示例 CSV（含缺失值与重复行） |
| `outputs/sample_report.json` | 对示例数据生成的真实 JSON 报告 |
| `outputs/sample_dedup.csv` | 对应的去重输出文件 |

## 验证结果

- 测试：`cd project && python3 -m unittest discover -s tests -v` → **Ran 21 tests, OK**（全部通过）
- 去重端到端实跑：示例数据重复行 2，去重输出保留 4 行去掉 2 行，输入文件 md5 校验未变
- 依赖：仅标准库（argparse/csv/io/json/os/dataclasses/collections/datetime/typing/unittest 等），未安装任何第三方包
- 边界验证：空文件、仅表头文件、字段数不一致文件均正常输出并给出 `warnings` 提示
- 示例数据实跑：6 行 × 4 列，缺失单元格 5 个，重复行 2 行（两组重复，各出现 2 次）

## 关键口径

- 重复行数 = 每组相同行「出现次数 − 1」，首次出现不计入重复。
- 重复行按 CSV 解析后的原始字段逐一比较，空白字符不同不算重复；缺失值判断仍去首尾空白（两套口径独立）。
- `--dedupe-output` 保留每组首个出现的完整行，输入文件不变；报告 `duplicate_row_count` 与 `dedupe_output.rows_removed` 一致，不一致时退出码 2。
- 拒绝将去重结果写回输入文件（同路径 / 软链接 / 硬链接），退出码 2。
- 行号从 1 起，不含表头行。
- 空单元格始终计为缺失；默认额外识别 `na`/`n/a`/`null`/`none`/`nan`（忽略大小写），可用 `--na-values` 覆盖。

## 遗留说明

- README 45 行，超出 40 行目标（新增 `--dedupe-output` 用法与口径说明所需，Markdown 段落间需空行）。
- 未做打包配置（`pyproject.toml`），按要求不安装依赖，直接以 `python3 -m csv_qc` 运行。

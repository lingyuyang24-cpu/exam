"""CSV 数据质量检查核心：逐列缺失值 + 完整重复行。仅依赖标准库。"""

from __future__ import annotations

import csv
import io
import json
import os
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Sequence

DEFAULT_NA_VALUES: frozenset[str] = frozenset({"", "na", "n/a", "null", "none", "nan"})
ENCODINGS: tuple[str, ...] = ("utf-8-sig", "utf-8", "gb18030", "latin-1")


@dataclass(frozen=True)
class CheckConfig:
    """检查参数。na_values 中的标记按小写比较，空单元格始终算缺失。"""

    na_values: frozenset[str] = DEFAULT_NA_VALUES
    delimiter: str | None = None
    encoding: str | None = None
    has_header: bool = True
    trim_whitespace: bool = True
    max_examples: int = 5


def _decode(raw: bytes, encoding: str | None) -> tuple[str, str]:
    """解码字节流，返回 (文本, 实际编码)。"""
    for enc in (encoding,) if encoding else ENCODINGS:
        try:
            return raw.decode(enc), enc
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("latin-1"), "latin-1"


def _sniff_delimiter(text: str) -> str:
    """嗅探分隔符，失败时回退到逗号。"""
    try:
        return csv.Sniffer().sniff(text[:8192], delimiters=",;\t|").delimiter
    except csv.Error:
        return ","


def check_csv(path: str | os.PathLike[str], config: CheckConfig | None = None) -> dict[str, Any]:
    """检查 CSV 文件，返回可直接 JSON 序列化的报告字典。

    缺失值：逐列统计缺失数量、缺失率、缺失值写法分布与示例行号。
    重复行：统计字段完全相同的行组，重复行数 = 每组出现次数 - 1。
    """
    config = config or CheckConfig()
    if not os.path.isfile(path):
        raise FileNotFoundError(f"CSV 文件不存在: {path}")

    with open(path, "rb") as handle:
        raw = handle.read()
    text, encoding = _decode(raw, config.encoding)
    delimiter = config.delimiter or _sniff_delimiter(text)

    rows = list(csv.reader(io.StringIO(text, newline=""), delimiter=delimiter))
    if config.has_header:
        header, data_rows = (rows[0], rows[1:]) if rows else ([], [])
    else:
        header, data_rows = [], rows

    width = len(header) if header else max((len(r) for r in data_rows), default=0)
    names = [
        (name.strip() if name and name.strip() else f"column_{i + 1}")
        for i, name in enumerate(header)
    ] or [f"column_{i + 1}" for i in range(width)]

    tokens = {token.strip().lower() for token in config.na_values} | {""}
    missing_count = [0] * width
    missing_kinds: list[Counter[str]] = [Counter() for _ in range(width)]
    examples: list[list[int]] = [[] for _ in range(width)]
    seen: dict[tuple[str, ...], list[int]] = {}

    for row_no, row in enumerate(data_rows, start=1):
        for i in range(width):
            raw_value = row[i] if i < len(row) else ""
            value = raw_value.strip() if config.trim_whitespace else raw_value
            if value.lower() in tokens:
                missing_count[i] += 1
                missing_kinds[i][value if value else "<empty>"] += 1
                if len(examples[i]) < config.max_examples:
                    examples[i].append(row_no)
        key = tuple((c.strip() if config.trim_whitespace else c) for c in row)
        seen.setdefault(key, []).append(row_no)

    total = len(data_rows)
    columns = [
        {
            "name": names[i],
            "index": i,
            "missing_count": missing_count[i],
            "missing_ratio": round(missing_count[i] / total, 6) if total else 0.0,
            "missing_values": dict(sorted(missing_kinds[i].items())),
            "example_row_numbers": examples[i],
        }
        for i in range(width)
    ]

    duplicate_groups = []
    duplicate_rows = 0
    for key, row_numbers in seen.items():
        if len(row_numbers) > 1:
            duplicate_rows += len(row_numbers) - 1
            duplicate_groups.append(
                {
                    "values": list(key),
                    "occurrences": len(row_numbers),
                    "duplicate_count": len(row_numbers) - 1,
                    "row_numbers": row_numbers,
                }
            )

    warnings = []
    if not rows:
        warnings.append("文件为空。")
    elif config.has_header and not data_rows:
        warnings.append("文件只有表头，没有数据行。")
    if any(len(r) != width for r in data_rows):
        warnings.append("存在字段数与表头不一致的行，已按空字符串补齐。")

    return {
        "file": os.fspath(path),
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "encoding": encoding,
        "delimiter": delimiter,
        "total_rows": total,
        "column_count": width,
        "columns": columns,
        "total_missing_values": sum(missing_count),
        "columns_with_missing": sum(1 for c in missing_count if c > 0),
        "unique_row_count": len(seen),
        "duplicate_row_count": duplicate_rows,
        "duplicate_group_count": len(duplicate_groups),
        "duplicate_groups": duplicate_groups,
        "warnings": warnings,
    }


def check_csv_json(path: str | os.PathLike[str], config: CheckConfig | None = None, indent: int = 2) -> str:
    """检查 CSV 并返回 JSON 字符串。"""
    return json.dumps(check_csv(path, config), indent=indent or None, ensure_ascii=False)

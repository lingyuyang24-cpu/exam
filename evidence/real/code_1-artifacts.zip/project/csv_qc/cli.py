"""命令行入口：检查 CSV 并输出 JSON 报告。"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

from .core import DEFAULT_NA_VALUES, CheckConfig, check_csv


def build_parser() -> argparse.ArgumentParser:
    """构建参数解析器。"""
    parser = argparse.ArgumentParser(
        prog="csv-qc", description="检查 CSV 的缺失值与完整重复行，输出 JSON 报告。"
    )
    parser.add_argument("csv_path", help="待检查的 CSV 文件路径")
    parser.add_argument("-o", "--output", default="-", help="报告输出路径，- 表示标准输出（默认）")
    parser.add_argument("--encoding", default=None, help="指定编码，默认自动探测")
    parser.add_argument("--delimiter", default=None, help="指定分隔符，默认自动嗅探")
    parser.add_argument(
        "--na-values",
        default=None,
        help="额外缺失标记，逗号分隔（忽略大小写）。默认："
        + ",".join(sorted(DEFAULT_NA_VALUES - {""})),
    )
    parser.add_argument("--no-header", action="store_true", help="首行不是表头")
    parser.add_argument("--indent", type=int, default=2, help="JSON 缩进，0 表示不缩进")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """主入口，返回进程退出码。"""
    args = build_parser().parse_args(argv)

    na_values = DEFAULT_NA_VALUES
    if args.na_values is not None:
        na_values = frozenset(t.strip() for t in args.na_values.split(",") if t.strip())
    config = CheckConfig(
        na_values=na_values,
        delimiter=args.delimiter,
        encoding=args.encoding,
        has_header=not args.no_header,
    )

    try:
        report = check_csv(args.csv_path, config)
    except FileNotFoundError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"错误: 读取文件失败: {exc}", file=sys.stderr)
        return 2

    payload = json.dumps(report, indent=args.indent or None, ensure_ascii=False)
    if args.output == "-":
        print(payload)
    else:
        try:
            with open(args.output, "w", encoding="utf-8") as handle:
                handle.write(payload + "\n")
        except OSError as exc:
            print(f"错误: 无法写入 {args.output}: {exc}", file=sys.stderr)
            return 2
        print(
            f"报告已写入 {args.output}: {report['total_rows']} 行, "
            f"{report['column_count']} 列, 缺失 {report['total_missing_values']} 个, "
            f"重复行 {report['duplicate_row_count']} 行"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

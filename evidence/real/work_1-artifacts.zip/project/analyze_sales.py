#!/usr/bin/env python3
"""十月销售数据分析（第一版）。

口径：全部订单，订单金额 = 数量 * 单价（不含税、成本、退款等未提供信息）。
输入：uploads/92e6e778_sales.csv, uploads/5821dd10_meeting_notes.md
输出：outputs/summary.csv（region,total_sales）, outputs/report.md
"""

from __future__ import annotations

import csv
import re
from collections import OrderedDict, defaultdict
from datetime import date
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"

SALES_CSV = UPLOADS / "92e6e778_sales.csv"
NOTES_MD = UPLOADS / "5821dd10_meeting_notes.md"
SUMMARY_CSV = OUTPUTS / "summary.csv"
REPORT_MD = OUTPUTS / "report.md"

AMOUNT_FORMULA = "订单金额 = 数量(quantity) × 单价(unit_price)"
CALIBER = "全部订单（含已取消、待付款），不做状态过滤"


# ---------- 通用工具 ----------

def fmt_amount(value: float) -> str:
    """整数金额不带小数点，否则保留两位。"""
    if float(value).is_integer():
        return str(int(value))
    return f"{value:.2f}"


def fmt_pct(part: float, whole: float) -> str:
    if not whole:
        return "—"
    return f"{part / whole * 100:.1f}%"


def md_table(headers, rows) -> str:
    lines = ["| " + " | ".join(headers) + " |",
             "| " + " | ".join("---" for _ in headers) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(str(c) for c in row) + " |")
    return "\n".join(lines)


# ---------- 1. 读取并校验销售数据 ----------

def load_orders(path: Path):
    """读取订单并做基础校验；返回 (orders, checks)。"""
    orders = []
    checks = []
    with path.open(encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        required = ["order_id", "date", "region", "product", "quantity", "unit_price", "status"]
        missing = [c for c in required if c not in (reader.fieldnames or [])]
        if missing:
            raise SystemExit(f"销售数据缺少必要列: {missing}")
        checks.append(f"表头完整，包含 {len(required)} 个必要字段: {', '.join(required)}")
        for lineno, row in enumerate(reader, start=2):
            order = {
                "order_id": (row["order_id"] or "").strip(),
                "date": (row["date"] or "").strip(),
                "region": (row["region"] or "").strip(),
                "product": (row["product"] or "").strip(),
                "quantity": int(row["quantity"]),
                "unit_price": float(row["unit_price"]),
                "status": (row["status"] or "").strip(),
                "line": lineno,
            }
            for key in ("order_id", "date", "region", "product", "status"):
                if not order[key]:
                    raise SystemExit(f"第 {lineno} 行字段 {key} 为空")
            order["amount"] = order["quantity"] * order["unit_price"]
            orders.append(order)

    ids = [o["order_id"] for o in orders]
    dupes = sorted({i for i in ids if ids.count(i) > 1})
    checks.append(f"订单行数 {len(orders)} 条；order_id 唯一: {'是' if not dupes else '否 ' + str(dupes)}")
    dates = sorted(o["date"] for o in orders)
    checks.append(f"订单日期区间 {dates[0]} 至 {dates[-1]}（日期格式 YYYY-MM-DD）")
    checks.append(f"金额字段由 {AMOUNT_FORMULA} 计算，未做任何人工调整")
    return orders, checks


# ---------- 2. 汇总计算 ----------

def aggregate(orders):
    """按区域 / 产品 / 状态汇总金额与订单数。"""
    region = defaultdict(lambda: {"amount": 0.0, "count": 0, "qty": 0})
    product = defaultdict(lambda: {"amount": 0.0, "count": 0, "qty": 0})
    status = defaultdict(lambda: {"amount": 0.0, "count": 0, "qty": 0})
    for o in orders:
        for bucket, key in ((region, o["region"]), (product, o["product"]), (status, o["status"])):
            bucket[key]["amount"] += o["amount"]
            bucket[key]["count"] += 1
            bucket[key]["qty"] += o["quantity"]
    return region, product, status


def sort_rows(bucket):
    """按金额降序排序，金额相同按名称升序，保证结果稳定可复现。"""
    return sorted(bucket.items(), key=lambda kv: (-kv[1]["amount"], kv[0]))


def region_product_breakdown(orders, region_name):
    """某区域的产品金额构成。"""
    agg = defaultdict(lambda: {"amount": 0.0, "count": 0, "qty": 0})
    for o in orders:
        if o["region"] == region_name:
            agg[o["product"]]["amount"] += o["amount"]
            agg[o["product"]]["count"] += 1
            agg[o["product"]]["qty"] += o["quantity"]
    return sort_rows(agg)


def region_non_completed(orders, region_name, done_status="已完成"):
    """某区域非“已完成”订单的金额、订单数与明细。"""
    rows = [o for o in orders
            if o["region"] == region_name and o["status"] != done_status]
    amount = sum(o["amount"] for o in rows)
    detail = "、".join(f"{o['order_id']}（{fmt_amount(o['amount'])}，{o['status']}）" for o in rows)
    return amount, len(rows), detail


def cancelled_consistency(sp, orders, products):
    """核对发言人提到的产品与该区域“已取消”订单的产品是否一致。

    返回 (提示语, 待确认问题条目)；一致或无法判断时返回空字符串。
    """
    if not sp.get("region") or "取消" not in sp["statement"]:
        return "", None
    cancelled = [o for o in orders
                 if o["region"] == sp["region"] and o["status"] == "已取消"]
    if not cancelled:
        return "", None
    mentioned = [name for name in products if name in sp["statement"]]
    actual = sorted({o["product"] for o in cancelled})
    if mentioned and not set(mentioned) & set(actual):
        detail = "、".join(f"{o['order_id']}（{o['product']}，{fmt_amount(o['amount'])}）"
                           for o in cancelled)
        msg = (f"记录提到“{'、'.join(mentioned)}”，但该区域已取消订单为 {detail}，"
               "记录表述与数据不一致，需核对")
        return msg, msg
    return "", None


def contrast_note(statement):
    """根据会议记录原文中的关键词给出可核对性说明（不引入外部推断）。"""
    notes = []
    if "库存" in statement:
        notes.append("记录提到库存，但材料未提供库存余额，无法核对")
    if "取消" in statement or "待付款" in statement or "未付款" in statement:
        notes.append("记录提到取消/待付款订单，其金额见左列；本版口径 A 未剔除，口径 B 已作对照")
    if "补货" in statement or "区域销售额" in statement:
        notes.append("记录要求核对区域销售额，见第二节")
    if "口径" in statement:
        notes.append("记录要求说明统计口径，见第一节")
    if "成本" in statement or "税费" in statement or "退款" in statement:
        notes.append("记录说明无税费/成本/退款数据，本报告未做相关推算")
    if not notes:
        notes.append("记录表述与本次汇总指标无直接可核对项")
    return "；".join(notes)


# ---------- 3. 解析会议记录 ----------

TODO_RE = re.compile(r"^(.+?)在\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日前\s*(.+)$")
SPEAKER_RE = re.compile(r"^(.+?)负责人(.+?)[:：](.+)$")


def parse_notes(path: Path, regions):
    """从会议记录中提取发言人观点、待办与待确认事项。"""
    text = path.read_text(encoding="utf-8")
    meta = {"title": "", "date": "", "disclaimer": ""}
    speakers, todos, opens = [], [], []

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("# "):
            meta["title"] = line[2:].strip()
            continue
        if line.startswith("会议日期"):
            # 该行形如 "会议日期：2026-10-15。以下均为演示用虚构数据。"
            after = line.split("：", 1)[1].strip()
            segs = [seg.strip() for seg in after.split("。") if seg.strip()]
            if segs:
                meta["date"] = segs[0]
            if len(segs) > 1:
                meta["disclaimer"] = "。".join(segs[1:])
            continue
        if line.startswith("以下均为"):
            meta["disclaimer"] = line.lstrip("- ").strip()
            continue
        if not line.startswith("- "):
            continue
        body = line[2:].strip()

        if body.startswith("待办："):
            block = body[len("待办："):].strip().rstrip("。")
            for chunk in block.split("；"):
                chunk = chunk.strip()
                if not chunk:
                    continue
                m = TODO_RE.match(chunk)
                if m:
                    owner, month, day, task = m.groups()
                    todos.append({
                        "owner": owner.strip(),
                        "deadline": f"2026-{int(month):02d}-{int(day):02d}",
                        "task": task.strip(),
                    })
                else:
                    todos.append({"owner": "未标注", "deadline": "未标注", "task": chunk})
            continue

        if body.startswith("尚待确认："):
            block = body[len("尚待确认："):].strip().rstrip("。")
            parts = [p.strip() for p in block.split("，") if p.strip()]
            items = [i for p in parts[:1] for i in p.split("、") if i]
            note = parts[1] if len(parts) > 1 else ""
            opens.append({"items": items, "note": note})
            continue

        m = SPEAKER_RE.match(body)
        if m:
            role_desc, name, statement = (g.strip() for g in m.groups())
            speakers.append({
                "region": role_desc if role_desc in regions else "",
                "dept": role_desc if role_desc not in regions else "",
                "name": name,
                "statement": statement,
            })
        else:
            speakers.append({"region": "", "dept": "", "name": "", "statement": body})

    return meta, speakers, todos, opens


# ---------- 4. 输出 summary.csv ----------

def write_summary_csv(region_bucket, path: Path):
    rows = sort_rows(region_bucket)
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh, lineterminator="\n")
        writer.writerow(["region", "total_sales"])
        for name, agg in rows:
            writer.writerow([name, fmt_amount(agg["amount"])])
    return rows


# ---------- 5. 生成报告 ----------

def build_report(orders, checks, region, product, status, region_done, meta, speakers, todos, opens):
    total = sum(o["amount"] for o in orders)
    total_qty = sum(o["quantity"] for o in orders)
    done_total = sum(agg["amount"] for agg in region_done.values())
    done_orders = [o for o in orders if o["status"] == "已完成"]
    today = date.today()

    parts = []
    parts.append("# 十月销售数据分析报告\n")
    parts.append(
        f"- 生成日期：{today.isoformat()}\n"
        f"- 销售数据区间：{orders[0]['date']} 至 {orders[-1]['date']}\n"
        f"- 会议日期：{meta['date'] or '未标注'}（{meta['title'] or '会议记录'}）\n"
        f"- 分析脚本：`project/analyze_sales.py`（本报告所有数字均由该脚本计算生成）\n"
    )

    # 1 材料来源与统计口径
    parts.append("\n## 一、材料来源与统计口径\n")
    parts.append(md_table(
        ["材料", "路径", "用途"],
        [
            ["销售数据", "`uploads/92e6e778_sales.csv`", "订单明细（12 行、7 字段），区域/产品/状态金额均由此计算"],
            ["会议记录", "`uploads/5821dd10_meeting_notes.md`", "区域负责人关注点、待办事项、待确认问题"],
        ]))
    parts.append(
        "\n**统计口径**\n\n"
        f"1. **样本范围**：{CALIBER}。共 {len(orders)} 条订单，覆盖 {orders[0]['date']} 至 {orders[-1]['date']}。\n"
        f"2. **金额定义**：{AMOUNT_FORMULA}。材料未提供折扣、税费、运费、成本、退款信息，故金额为“订单金额”，不等于收入或利润。\n"
        f"3. **汇总维度**：`summary.csv` 按区域汇总全部订单金额；产品排名、状态金额同样基于全部订单，**未**剔除已取消与待付款订单。\n"
        f"4. **排序规则**：各汇总表按金额降序排列，金额相同时按名称升序，保证结果可复现。\n"
        f"5. **金额格式**：结果均为整数，未做四舍五入处理。\n"
        f"6. **数据性质**：{'会议记录注明“' + meta['disclaimer'] + '”，' if meta['disclaimer'] else ''}故结论仅适用于该演示数据，不作为真实经营结论。\n"
    )
    parts.append(
        "\n> 口径提示（来自会议记录，需确认）：华南负责人提出“取消与待付款订单不能直接算入已实现收入”。"
        "本版按任务要求统计全部订单；文中同时给出“仅已完成”口径的对照数据，但**不**据此改动 `summary.csv`。\n"
    )

    # 2 区域销售额
    parts.append("\n## 二、区域销售额\n")
    parts.append(f"**口径 A：全部订单（第一版主口径，对应 `summary.csv`）**\n")
    parts.append(md_table(
        ["排名", "区域", "订单数", "数量合计", "订单金额", "金额占比"],
        [[i, name, agg["count"], agg["qty"], fmt_amount(agg["amount"]),
          fmt_pct(agg["amount"], total)]
         for i, (name, agg) in enumerate(sort_rows(region), 1)]))
    parts.append(
        f"\n合计：{len(orders)} 单，数量 {total_qty} 件，订单金额 {fmt_amount(total)}。\n"
    )

    parts.append("\n**口径 B：仅已完成（对照口径，供确认用，非 summary.csv 内容）**\n")
    parts.append(md_table(
        ["区域", "已完成订单数", "已完成金额", "与口径 A 差额"],
        [[name, region_done[name]["count"], fmt_amount(region_done[name]["amount"]),
          fmt_amount(region[name]["amount"] - region_done[name]["amount"])]
         for name, _ in sort_rows(region)]))
    parts.append(
        f"\n口径 B 合计 {fmt_amount(done_total)}，与口径 A 相差 {fmt_amount(total - done_total)}"
        f"（占比 {fmt_pct(total - done_total, total)}），差额来自已取消与待付款订单。\n"
    )

    # 3 产品排名
    parts.append("\n## 三、产品排名\n")
    parts.append(md_table(
        ["排名", "产品", "订单数", "数量合计", "订单金额", "金额占比"],
        [[i, name, agg["count"], agg["qty"], fmt_amount(agg["amount"]),
          fmt_pct(agg["amount"], total)]
         for i, (name, agg) in enumerate(sort_rows(product), 1)]))
    prod_rank = [name for name, _ in sort_rows(product)]
    parts.append(
        f"\n- 全部订单口径下，{prod_rank[0]}金额最高（{fmt_amount(product[prod_rank[0]]['amount'])}），"
        f"{prod_rank[-1]}最低（{fmt_amount(product[prod_rank[-1]]['amount'])}），"
        f"首尾差距 {fmt_amount(product[prod_rank[0]]['amount'] - product[prod_rank[-1]]['amount'])}。\n"
    )
    done_prod = defaultdict(lambda: {"amount": 0.0, "count": 0})
    for o in done_orders:
        done_prod[o["product"]]["amount"] += o["amount"]
        done_prod[o["product"]]["count"] += 1
    parts.append("\n**仅已完成口径下的产品排名（对照）**\n")
    parts.append(md_table(
        ["排名", "产品", "已完成订单数", "已完成金额"],
        [[i, name, agg["count"], fmt_amount(agg["amount"])]
         for i, (name, agg) in enumerate(sort_rows(done_prod), 1)]))
    top_all = prod_rank[0]
    top_done = sort_rows(done_prod)[0][0]
    if top_all != top_done:
        excluded = [o for o in orders if o["product"] == top_all and o["status"] != "已完成"]
        parts.append(
            f"\n- 口径差异提示：全部订单口径下第一名是{top_all}，仅已完成口径下变为{top_done}。"
            f"原因是{top_all}包含非“已完成”订单 "
            + "、".join(f"{o['order_id']}（{fmt_amount(o['amount'])}，{o['status']}）" for o in excluded)
            + f"，合计 {fmt_amount(sum(o['amount'] for o in excluded))}。\n"
        )

    # 4 订单状态金额
    parts.append("\n## 四、各订单状态金额\n")
    parts.append(md_table(
        ["订单状态", "订单数", "数量合计", "订单金额", "金额占比"],
        [[name, agg["count"], agg["qty"], fmt_amount(agg["amount"]), fmt_pct(agg["amount"], total)]
         for name, agg in sort_rows(status)]))
    parts.append(
        f"\n全部 {len(orders)} 单金额合计 {fmt_amount(total)}，与区域汇总、状态汇总、产品汇总三张表交叉核对一致。\n"
    )
    parts.append("\n**逐单明细**\n")
    parts.append(md_table(
        ["订单号", "日期", "区域", "产品", "数量", "单价", "订单金额", "状态"],
        [[o["order_id"], o["date"], o["region"], o["product"], o["quantity"],
          fmt_amount(o["unit_price"]), fmt_amount(o["amount"]), o["status"]] for o in orders]))

    # 5 会议待办
    parts.append("\n## 五、会议待办\n")
    if todos:
        owner_region = {s["name"]: s["region"] for s in speakers if s["name"]}
        rows = []
        for t in todos:
            overdue = ""
            if re.match(r"\d{4}-\d{2}-\d{2}$", t["deadline"]):
                y, m, d = (int(x) for x in t["deadline"].split("-"))
                overdue = "已过期" if date(y, m, d) < today else "未到期"
            rows.append([t["owner"], owner_region.get(t["owner"], "—"), t["deadline"],
                         overdue, t["task"]])
        parts.append(md_table(["负责人", "负责区域", "截止日期", "截止状态", "事项"], rows))
        parts.append(
            f"\n截止状态以生成日期 {today.isoformat()} 判定；会议记录中未记录任何待办的完成情况，需向负责人确认实际进度。\n"
        )
    else:
        parts.append("会议记录中未提取到待办事项。\n")

    if speakers:
        parts.append("\n**会议记录中的区域负责人关注点**\n")
        parts.append(md_table(
            ["发言人", "角色/区域", "记录原文要点"],
            [[s["name"] or "—", s["region"] or s["dept"] or "—", s["statement"]] for s in speakers]))

        parts.append("\n**会议记录观点与销售数据核对（全部订单口径）**\n")
        check_rows = []
        inconsistencies = []
        prod_names = [name for name, _ in sort_rows(product)]
        for sp in speakers:
            note = contrast_note(sp["statement"])
            inc_msg, inc_row = cancelled_consistency(sp, orders, prod_names)
            if inc_msg:
                note = f"{note}；{inc_msg}"
                inconsistencies.append((sp, inc_row))
            if not sp["region"]:
                check_rows.append([sp["name"] or "—", sp["dept"] or "—", "—（非区域负责人）", note])
                continue
            reg_amount = region[sp["region"]]["amount"]
            comp = []
            for i, (pname, pagg) in enumerate(region_product_breakdown(orders, sp["region"]), 1):
                comp.append(f"{pname} {fmt_amount(pagg['amount'])}"
                            f"（{pagg['count']} 单，占该区域 {fmt_pct(pagg['amount'], reg_amount)}，第 {i} 名）")
            nc_amount, nc_count, nc_detail = region_non_completed(orders, sp["region"])
            data_str = (f"区域金额 {fmt_amount(reg_amount)}（{region[sp['region']]['count']} 单）；"
                        f"产品构成：{'、'.join(comp)}；"
                        f"非“已完成”订单 {fmt_amount(nc_amount)}"
                        f"（{nc_count} 单，占该区域 {fmt_pct(nc_amount, reg_amount)}）"
                        + (f"，明细 {nc_detail}" if nc_detail else "，无"))
            check_rows.append([sp["name"] or "—", sp["region"], data_str, note])
        parts.append(md_table(["发言人", "区域", "数据核对结果", "与记录表述的对照"], check_rows))
        parts.append(
            "\n> 上表仅使用销售数据中的金额与状态字段，未引入库存、成本或趋势类推断；"
            "记录中提到但材料未提供的数据一律标注为“无法核对”。\n"
        )

    # 6 待确认问题
    parts.append("\n## 六、待确认问题\n")
    open_rows = []
    for blk in opens:
        for item in blk["items"]:
            open_rows.append([item, blk["note"] or "会议记录未说明"])
    open_rows.append(["统计口径：已取消/待付款订单是否应计入“已实现收入”",
                       "会议记录中提出该疑问但未形成结论；本版按任务要求统计全部订单，口径 A/B 对照数据见第二、四节"])
    for sp, msg in inconsistencies:
        open_rows.append([f"记录表述与数据不一致（{sp['name']}/{sp['region']}）", msg])
    open_rows.append(["会议记录截止日后的执行进展",
                       f"待办截止日为 2026-10-17 / 2026-10-18，截至 {today.isoformat()} 已过期，材料未记录完成情况"])
    parts.append(md_table(["待确认问题", "来源与说明"], open_rows))
    parts.append(
        "\n> 利润、利润率、毛利以及订单取消原因均**无法**由本材料得出：数据中没有成本、税费、退款字段，"
        "会议记录也未记录取消原因。本报告不做相关推算。\n"
    )

    # 7 附录：区域 × 产品矩阵
    parts.append("\n## 七、附录：区域 × 产品 订单金额矩阵（全部订单）\n")
    prod_order = [name for name, _ in sort_rows(product)]
    matrix_rows = []
    for rname, ragg in sort_rows(region):
        cells = []
        for pname in prod_order:
            cell = [o for o in orders if o["region"] == rname and o["product"] == pname]
            cells.append(fmt_amount(sum(o["amount"] for o in cell)) if cell else "—")
        matrix_rows.append([rname] + cells + [fmt_amount(ragg["amount"])])
    parts.append(md_table(["区域"] + prod_order + ["合计"], matrix_rows))
    parts.append(
        "\n表中数字为该区域该产品的订单金额（数量 × 单价），`—` 表示无该组合订单。\n"
    )

    # 8 数据校验
    parts.append("\n## 八、数据校验与限制\n")
    parts.append("\n".join(f"- {c}" for c in checks))
    parts.append(
        "\n限制：\n"
        "- 样本仅 12 条订单、单一月份（2026-10），占比与排名对个别订单敏感，不做趋势推断。\n"
        "- 金额为订单金额，不含税费、运费、成本与退款，不代表已实现收入或利润。\n"
        "- 库存余额、取消原因、利润率缺少数据来源，未作估计。\n"
    )

    # 9 复现方式
    parts.append("\n## 九、复现方式\n")
    parts.append(
        "```bash\ncd <工作区根目录>\npython3 project/analyze_sales.py\n```\n\n"
        "脚本重新生成 `outputs/summary.csv` 与 `outputs/report.md`，仅依赖 Python 标准库。\n"
    )
    return "\n".join(parts)


# ---------- 主流程 ----------

def main():
    OUTPUTS.mkdir(parents=True, exist_ok=True)

    orders, checks = load_orders(SALES_CSV)
    region, product, status = aggregate(orders)

    done_orders = [o for o in orders if o["status"] == "已完成"]
    region_done, _, _ = aggregate(done_orders)

    meta, speakers, todos, opens = parse_notes(NOTES_MD, set(region))

    region_rows = write_summary_csv(region, SUMMARY_CSV)

    report = build_report(orders, checks, region, product, status, region_done,
                          meta, speakers, todos, opens)
    REPORT_MD.write_text(report, encoding="utf-8")

    # 控制台核对输出
    total = sum(o["amount"] for o in orders)
    print(f"订单数: {len(orders)}  数量合计: {sum(o['quantity'] for o in orders)}  金额合计: {fmt_amount(total)}")
    print("区域汇总 (全部订单):")
    for name, agg in region_rows:
        print(f"  {name}: {fmt_amount(agg['amount'])}  ({agg['count']} 单)")
    print("状态汇总:")
    for name, agg in sort_rows(status):
        print(f"  {name}: {fmt_amount(agg['amount'])}  ({agg['count']} 单)")
    print("产品排名:")
    for i, (name, agg) in enumerate(sort_rows(product), 1):
        print(f"  {i}. {name}: {fmt_amount(agg['amount'])}")
    print(f"交叉校验: 区域 {fmt_amount(sum(a['amount'] for a in region.values()))} / "
          f"产品 {fmt_amount(sum(a['amount'] for a in product.values()))} / "
          f"状态 {fmt_amount(sum(a['amount'] for a in status.values()))} / "
          f"逐单 {fmt_amount(total)}")
    print(f"已写出: {SUMMARY_CSV}")
    print(f"已写出: {REPORT_MD}")


if __name__ == "__main__":
    main()
